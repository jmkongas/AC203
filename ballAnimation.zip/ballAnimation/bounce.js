// alert ("It is working!");

//Declaring and initializing variables
var canvas;
var ctx;
var x = 0;   //setting the original position of the ball
var y = 300;
var width = 600;
var height = 300;
//small changes in x and y direction at each frame
var mx = 2;
var my = 2;

function init(){
	canvas = document.getElementById("myCanvas");
	ctx = canvas.getContext("2d");
	return setInterval(drawBall,10);
}

function circle(x,y,r){
	ctx.beginPath();
	ctx.arc(x,y,r,0,6.28);
	ctx.closePath();
	ctx.fillStyle="tomato";
	ctx.fill();
}

function drawBall(){
	

}